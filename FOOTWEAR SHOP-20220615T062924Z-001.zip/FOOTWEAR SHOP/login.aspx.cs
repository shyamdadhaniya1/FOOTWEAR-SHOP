﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;


public partial class login : System.Web.UI.Page
{
    String strcon = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\footwear.mdf;Integrated Security=True;User Instance=True";
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    //protected void btnlogin_Click(object sender, EventArgs e)
    //{
    //    SqlConnection con = new SqlConnection(strcon);
    //    con.Open();
    //    String qry = "select * from login where username='" + txtnm.Text + "'and password='" + txtpass.Text + "'";
    //    SqlDataAdapter adpt = new SqlDataAdapter(qry, con);
    //    DataTable dt = new DataTable();
    //    adpt.Fill(dt);
    //    if (dt.Rows.Count == 1)
    //    {
    //        Response.Write("<Script>alert('Login Sucessfully')</Script>");
    //        Response.Redirect("Home.aspx");
    //    }
    //    else
    //    {
    //        Response.Write("<script language='javascript'>alert('invalid username or password')</script>");
    //    }
    //}
    protected void btnlogin_Click1(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        String qry = "select name,password from registration where name='" + txtnm.Text + "'and password='" + txtpass.Text + "'";
        SqlDataAdapter adpt = new SqlDataAdapter(qry, con);
        DataTable dt = new DataTable();
        adpt.Fill(dt);
        if (dt.Rows.Count == 1)
        {
            String str = "";
            if (Session.Contents.Count != 0)
            {
                str += Session["cart"].ToString();
            }
            Session["uid"] = dt.Rows[0][0].ToString();
            Session["uname"] = dt.Rows[0][0].ToString();

            if (str == "" || str == null)
            {
                Response.Redirect("Default.aspx");
            }
            else
            {
                Response.Redirect(str);
            }
        }
        else
        {
            Response.Write("<script language='javascript'>alert('invalid username or password')</script>");
        }
        
    }
}