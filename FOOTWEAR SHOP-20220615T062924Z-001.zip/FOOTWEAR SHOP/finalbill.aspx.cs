﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using System.Text;
using System.IO;

public partial class finalbill : System.Web.UI.Page
{
    String strcon = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\footwear.mdf;Integrated Security=True;User Instance=True";
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!Page.IsPostBack)
        {
            if (Session.Contents.Count >= 0)
            {
                showcart();
                counttotal();
                lbluser.Text = Session["uname"].ToString();

                Response.ContentType = "application/pdf";
                Response.AddHeader("content-disposition", "attachment;filename=BILL.pdf");
                Response.Cache.SetCacheability(HttpCacheability.NoCache);
                StringWriter sw = new StringWriter();
                HtmlTextWriter hw = new HtmlTextWriter(sw);
                this.Page.RenderControl(hw);
                StringReader sr = new StringReader(sw.ToString());
                Document pdfDoc = new Document(PageSize.A4, 10f, 10f, 100f, 0f);
                HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
                PdfWriter.GetInstance(pdfDoc, Response.OutputStream);
                pdfDoc.Open();
                htmlparser.Parse(sr);
                pdfDoc.Close();
                Response.Write(pdfDoc);
                SqlConnection con=new SqlConnection(strcon);
                SqlCommand cmd = new SqlCommand("truncate table CART", con);
                con.Open();
                cmd.ExecuteNonQuery();
                Response.End();
                Response.Redirect("Home.aspx");
            }
        }
    }

    public string getData(GridView gv)
    {
        StringBuilder StrBilder = new StringBuilder();
        StringWriter strWriter = new StringWriter(StrBilder);
        HtmlTextWriter htw = new HtmlTextWriter(strWriter);
        gv.RenderControl(htw);
        return StrBilder.ToString();
    }

    protected void showcart()
    {
        String qry = "select * from CART where UID='" + Session["uid"].ToString() + "'";
        SqlConnection con = new SqlConnection(strcon);
        SqlDataAdapter adpt = new SqlDataAdapter(qry, con);
        DataTable dt = new DataTable();
        adpt.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            Repeater1.DataSource = dt;
            Repeater1.DataBind();
        }
    }


    protected void counttotal()
    {
        int total = 0;
        int val;
        String qry = "select * from CART where UID='" + Session["uid"].ToString() + "'";
        SqlConnection con = new SqlConnection(strcon);
        SqlDataAdapter adpt = new SqlDataAdapter(qry, con);
        DataTable dt = new DataTable();
        adpt.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                String str = dt.Rows[i]["TOTAL"].ToString();
                String[] abc = str.Split('=');
                String v = abc[1].Remove(abc[1].Length - 1);
                val = int.Parse(v);
                total += val;
            }

            Label2.Text = total.ToString();
        }
    }
}
 
