﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class registration : System.Web.UI.Page
{
    String strcon = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\footwear.mdf;Integrated Security=True;User Instance=True";
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnregistarion_Click(object sender, EventArgs e)
    {
       //SqlConnection con = new SqlConnection(con);
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        string qry = "insert into registration values('" + txtnm.Text + "','" + Txtpass.Text + "','" +txtcity.Text + "','" + txtcn.Text + "','" + txtadr.Text + "','" + txtmail.Text + "')";
        SqlCommand cmd = new SqlCommand(qry, con);
        cmd.ExecuteNonQuery();
        con.Close();
        Response.Write("<script>alert('Insert Success')</script>");
        //Response.Redirect("Default.aspx");
    }
}
 //protected void btnregi_Click(object sender, EventArgs e)
 //   {
       
 //   }
 //  protected void Button1_Click(object sender, EventArgs e)
 //  {
 //      txtnm.Text = "";
 //      txtpass.Text = "";
 //      txtcity.Text = "";
 //      txtadr.Text = "";
 //      txtcn.Text = "";
 //      txtmail.Text = "";
 //  }