﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class admin_mproduct1 : System.Web.UI.Page
{
    String strcon = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\footwear.mdf;Integrated Security=True;User Instance=True";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            display();


            getcat();
        }
        
    }

    protected void display()
    {
        
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        String qry = "select * from product";
        SqlDataAdapter adpt = new SqlDataAdapter(qry, con);
        DataTable dt = new DataTable();
        adpt.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }

    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "DELETE")
        {

            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            string qry = "DELETE FROM product WHERE pid='" + e.CommandArgument + "'";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.ExecuteNonQuery();
            con.Close();
            Response.Redirect("mproduct1.aspx");
            Response.Write("<script>alert('DELETE Success')</script>");

        }
        if (e.CommandName == "EDIT")
        {
            ViewState["pid"] = e.CommandArgument;
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            String qry = "select * from product where pid='" + e.CommandArgument + "'";
            SqlDataAdapter adpt = new SqlDataAdapter(qry, con);
            DataTable dt = new DataTable();
            adpt.Fill(dt);
            if (dt.Rows.Count > 0)
            {
               DropDownList1.SelectedValue = dt.Rows[0][1].ToString();
                txtname.Text = dt.Rows[0][2].ToString();
               
                Image1.ImageUrl = dt.Rows[0][3].ToString();

                ViewState["path"] = dt.Rows[0][3].ToString();
                txtsize.Text = dt.Rows[0][4].ToString();
                txtprice.Text = dt.Rows[0][5].ToString();
                Image1.Visible = true;
                btnupdate.Text = "UPDATE";
                ViewState["btn"] = 1;
            }
        }
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        e.Cancel = true;
    }
    protected void btnupdate_Click(object sender, EventArgs e)
    {

        if ( btnupdate.Text != "UPDATE")
        {
            String ext = System.IO.Path.GetExtension(FileUpload1.FileName);
            if (FileUpload1.HasFile)
            {
                if (ext == ".jpg" || ext == ".jpeg" || ext == ".png" || ext == ".JPEG")
                {
                    string uniq = DateTime.Now.Second + "_" + DateTime.Now.Millisecond + "_" + FileUpload1.FileName.ToString();
                    FileUpload1.SaveAs(Server.MapPath("~\\upload\\" + uniq));
                    string path = "~/upload/" + uniq;
                    SqlConnection con = new SqlConnection(strcon);
                    con.Open();
                    string qry = "insert into product values('" + DropDownList1.SelectedValue.ToString() + "','" + txtname.Text + "','" + path + "','"+txtsize.Text+"','"+txtprice.Text+"')";
                    SqlCommand cmd = new SqlCommand(qry, con);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    Response.Redirect("mproduct1.aspx");
                    Response.Write("<script>alert('Insert Success')</script>");
                }
            }
        }
        else
        {
            if (FileUpload1.HasFile)
            {
                String ext = System.IO.Path.GetExtension(FileUpload1.FileName);
                if (FileUpload1.HasFile)
                {
                    if (ext == ".jpg" || ext == ".jpeg" || ext == ".png" || ext == ".JPEG")
                    {
                        string uniq = DateTime.Now.Second + "_" + DateTime.Now.Millisecond + "_" + FileUpload1.FileName.ToString();
                        FileUpload1.SaveAs(Server.MapPath("~\\upload\\" + uniq));
                        string path = "~/upload/" + uniq;
                        SqlConnection con = new SqlConnection(strcon);
                        con.Open();
                        string qry = "UPDATE product SET ptype='" + DropDownList1.SelectedValue.ToString() + "', pname='" + txtname.Text + "',path='" + path + "', psize='" + txtsize.Text + "',price='" + txtprice.Text + "' WHERE pid='" + ViewState["pid"] + "'";
                        SqlCommand cmd = new SqlCommand(qry, con);
                        cmd.ExecuteNonQuery();
                        con.Close();
                        Response.Redirect("mproduct1.aspx");
                        Response.Write("<script>alert('Update Success');</script>");
                    }
                }
            }
            
          else
            {
                SqlConnection con = new SqlConnection(strcon);
                con.Open();
                string qry = "UPDATE product SET ptype='" + DropDownList1.SelectedValue.ToString() + "',pname='" + txtname.Text + "', psize='" + txtsize.Text + "',price='" + txtprice.Text + "'  WHERE pid='" + ViewState["pid"] + "'";
                SqlCommand cmd = new SqlCommand(qry, con);
                cmd.ExecuteNonQuery();
                con.Close();
                Response.Redirect("mproduct1.aspx");
                Response.Write("<script>alert('Insert Success')</script>");
            }
        }
    }


    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

        GridView1.PageIndex = e.NewPageIndex;
        display();
    }
    protected void getcat()
    {
        DropDownList1.Items.Clear();
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        String qry = "select cname from category";
        SqlDataAdapter adpt = new SqlDataAdapter(qry, con);
        DataTable dt = new DataTable();
        adpt.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                DropDownList1.Items.Add(dt.Rows[i][0].ToString());
            }
           DropDownList1.Items.Insert(0, new ListItem("--SELECT--", ""));
        }
        
    }
}
