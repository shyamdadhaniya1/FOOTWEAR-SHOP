﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class admin_product : System.Web.UI.Page
{
    String strcon = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\footwear.mdf;Integrated Security=True;User Instance=True";
    protected void Page_Load(object sender, EventArgs e)
    {
        getcat();

    }


    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (FileUpload1.HasFile)
        {
            String ext = System.IO.Path.GetExtension(FileUpload1.FileName);
            if (ext == ".jpg" || ext == ".jpeg" || ext == ".png" || ext == ".JPEG")
            {
                string uniq = DateTime.Now.Second + "_" + DateTime.Now.Millisecond + "_" + FileUpload1.FileName.ToString();
                FileUpload1.SaveAs(Server.MapPath("~\\upload\\" + uniq));
                string path = "~/upload/" + uniq;
                SqlConnection con = new SqlConnection(strcon);
                con.Open();
                string qry = "insert into product values('" + ddlcat.SelectedValue + "','" + txtname.Text + "','" + path + "','" + txtsize.Text + "','" + txtprice.Text + "')";
                SqlCommand cmd = new SqlCommand(qry, con);
                cmd.ExecuteNonQuery();
                con.Close();
                Response.Redirect("product.aspx");
                Response.Write("<script>alert('Insert Success')</script>");
            }
        }
    }
    protected void getcat()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        String qry = "select cname from category";
        SqlDataAdapter adpt = new SqlDataAdapter(qry, con);
        DataTable dt = new DataTable();
        adpt.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                ddlcat.Items.Add(dt.Rows[i][0].ToString());
            }
            ddlcat.Items.Insert(0, new ListItem("--SELECT--", ""));
        }
    }
}
