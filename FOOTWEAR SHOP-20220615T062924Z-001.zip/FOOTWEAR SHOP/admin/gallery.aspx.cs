﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class admin_gallery : System.Web.UI.Page
{
    String strcon = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\footwear.mdf;Integrated Security=True;User Instance=True";
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (FileUpload1.HasFile)
        {
            String ext = System.IO.Path.GetExtension(FileUpload1.FileName);
            if (ext == ".jpg" || ext == ".jpeg" || ext == ".png" || ext == ".JPEG")
            {
                string uniq = DateTime.Now.Second + "_" + DateTime.Now.Millisecond + "_" + FileUpload1.FileName.ToString();
                FileUpload1.SaveAs(Server.MapPath("~\\upload\\" + uniq));
                string path = "~/upload/" + uniq;
                SqlConnection con = new SqlConnection(strcon);
                con.Open();
                string qry = "insert into gallery values('" + path + "')";
                SqlCommand cmd = new SqlCommand(qry, con);
                cmd.ExecuteNonQuery();
                con.Close();
                Response.Redirect("gallery.aspx");
                Response.Write("<script>alert('Insert Success')</script>");
            }
        }
    }
}