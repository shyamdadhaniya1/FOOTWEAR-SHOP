﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class admin_Default : System.Web.UI.Page
{
    String strcon = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\footwear.mdf;Integrated Security=True;User Instance=True";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.IsPostBack == false)
        {
            lblmsg.Text = "***  Now You Are Secure For Login";
            lblmsg.ForeColor = System.Drawing.Color.Green;
        }
    }
    protected void btnlogin_Click(object sender, EventArgs e)
    {

        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        String qry = "select * from login where username='" + txtuser.Text + "' AND password='" + txtpass.Text + "'";
        SqlDataAdapter adpt = new SqlDataAdapter(qry, con);
        DataTable dt = new DataTable();
        adpt.Fill(dt);
      
        if (dt.Rows.Count > 0)
        {
           
            Session["user"] = dt.Rows[0]["username"].ToString();
            Session["dept"] = dt.Rows[0]["password"].ToString();
            Response.Redirect("~/admin/home.aspx");
            Response.Write("<script>alert('Login Success');</script>");
        }
        else
        {
           
            txtuser.Text = "";
            lblmsg.Text = "***  Sorry Username & Password Not Matched";
            lblmsg.ForeColor = System.Drawing.Color.Red;
            
        }
    }
}