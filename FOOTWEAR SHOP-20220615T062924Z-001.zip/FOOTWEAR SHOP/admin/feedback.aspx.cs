﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class admin_feedback : System.Web.UI.Page
{
    String strcon = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\footwear.mdf;Integrated Security=True;User Instance=True";
 
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            display();


        }
    }
    protected void display()
    {

        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        String qry = "select * from feedback";
        SqlDataAdapter adpt = new SqlDataAdapter(qry, con);
        DataTable dt = new DataTable();
        adpt.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }

    }

    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "DELETE")
        {

            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            string qry = "DELETE FROM feedback WHERE id='" + e.CommandArgument + "'";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.ExecuteNonQuery();
            con.Close();
            Response.Redirect("feedback.aspx");
            Response.Write("<script>alert('DELETE Success')</script>");

        }

    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        display(); 
    }
}