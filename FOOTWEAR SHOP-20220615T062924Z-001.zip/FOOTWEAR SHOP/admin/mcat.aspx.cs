﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class admin_mcat : System.Web.UI.Page
{
    String strcon = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\footwear.mdf;Integrated Security=True;User Instance=True";
    protected void Page_Load(object sender, EventArgs e)
    {
        display();


    }
    protected void display()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();

        string qry = "select * from category";
        SqlDataAdapter adpt = new SqlDataAdapter(qry, con);
        DataTable dt = new DataTable();
        adpt.Fill(dt);

        if (dt.Rows.Count > 0)
        {
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }

    }

    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "DELETE")
        {

            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            string qry = "DELETE FROM category WHERE id='" + e.CommandArgument + "'";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.ExecuteNonQuery();
            con.Close();
            Response.Redirect("mcat.aspx");
            Response.Write("<script>alert('DELETE Success')</script>");

        }
        if (e.CommandName == "EDIT")
        {
            ViewState["id"] = e.CommandArgument;
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            String qry = "select * from category where id='" + e.CommandArgument + "'";
            SqlDataAdapter adpt = new SqlDataAdapter(qry, con);
            DataTable dt = new DataTable();
            adpt.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                txtcat.Text = dt.Rows[0][1].ToString();
                
               Image1.ImageUrl = dt.Rows[0][2].ToString();

                ViewState["path"] = dt.Rows[0][2].ToString();
                
                Image1.Visible = true;
                btnupdate.Text = "UPDATE";
                ViewState["btn"] = 1;
            }
           
            //ViewState["id"] = e.CommandArgument;
            //SqlConnection con = new SqlConnection(strcon);
            //con.Open();
            //String qry = "select * from cate where id='" + e.CommandArgument + "'";
            //SqlDataAdapter adpt = new SqlDataAdapter(qry, con);
            //DataTable dt = new DataTable();
            //adpt.Fill(dt);
            //if (dt.Rows.Count > 0)
            //{
            //    txtcat.Text = dt.Rows[0][1].ToString();
            //    btnupdate.Text = "UPDATE";
            //    ViewState["btn"] = 1;
            //}
        } 

    }


    protected void  GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
{

}
protected void  GridView1_RowEditing(object sender, GridViewEditEventArgs e)
{
    e.Cancel = true;
}
protected void btnupdate_Click(object sender, EventArgs e)
{
    if (btnupdate.Text != "UPDATE")
    {
        String ext = System.IO.Path.GetExtension(FileUpload1.FileName);
        if (FileUpload1.HasFile)
        {
            if (ext == ".jpg" || ext == ".jpeg" || ext == ".png" || ext == ".JPEG")
            {
                string uniq = DateTime.Now.Second + "_" + DateTime.Now.Millisecond + "_" + FileUpload1.FileName.ToString();
                FileUpload1.SaveAs(Server.MapPath("~\\upload\\" + uniq));
                string path = "~/upload/" + uniq;
                SqlConnection con = new SqlConnection(strcon);
                con.Open();
                string qry = "insert into category values('" + txtcat.Text + "','" + path + "')";
                SqlCommand cmd = new SqlCommand(qry, con);
                cmd.ExecuteNonQuery();
                con.Close();
                Response.Redirect("mcat.aspx");
                Response.Write("<script>alert('Insert Success')</script>");
            }
        }
    }

    else
    {
        if (FileUpload1.HasFile)
        {
            String ext = System.IO.Path.GetExtension(FileUpload1.FileName);
            if (FileUpload1.HasFile)
            {
                if (ext == ".jpg" || ext == ".jpeg" || ext == ".png" || ext == ".JPEG")
                {
                    string uniq = DateTime.Now.Second + "_" + DateTime.Now.Millisecond + "_" + FileUpload1.FileName.ToString();
                    FileUpload1.SaveAs(Server.MapPath("~\\upload\\" + uniq));
                    string path = "~/upload/" + uniq;
                    SqlConnection con = new SqlConnection(strcon);
                    con.Open();
                    string qry = "UPDATE category SET cname='" + txtcat.Text + "',path='" + path + "' WHERE id='" + ViewState["id"] + "'";
                    SqlCommand cmd = new SqlCommand(qry, con);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    Response.Redirect("mcat.aspx");
                    Response.Write("<script>alert('Update Success');</script>");
                }
            }
        }
        else
        {
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            string qry = "UPDATE category SET cname='" + txtcat.Text + "'  WHERE id='" + ViewState["id"] + "'";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.ExecuteNonQuery();
            con.Close();
            Response.Redirect("mcat.aspx");
            Response.Write("<script>alert('Insert Success')</script>");
        }
    }
}

                            
   


protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
{
    GridView1.PageIndex = e.NewPageIndex;
    display();

}
}


           


    
  
            
           
            