﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Feedback : System.Web.UI.Page
{
    String strcon = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\footwear.mdf;Integrated Security=True;User Instance=True";
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnfeedback_Click(object sender, EventArgs e)
    {

        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        string qry = "insert into feedback values('" + txtnm.Text + "','" + Txtemail.Text + "','" + txtmsg.Text + "')";
        SqlCommand cmd = new SqlCommand(qry, con);
        cmd.ExecuteNonQuery();
        con.Close();
        Response.Write("<script language='javascript'>alert('Insert Success')</script>");
        txtnm.Text = String.Empty;
        Txtemail.Text = String.Empty;
        txtmsg.Text = String.Empty;

        //Response.Redirect(".aspx");
    }
}