﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class details : System.Web.UI.Page
{
    String strcon = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\footwear.mdf;Integrated Security=True;User Instance=True";
    protected void Page_Load(object sender, EventArgs e)
    {
        String strid = Request.QueryString["id"];

        String fnlid = strid.Replace("'", "");
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        SqlDataAdapter adpt = new SqlDataAdapter("select * From product where pid='" + fnlid + "'", con);
        DataTable dt = new DataTable();
        adpt.Fill(dt);

        if (dt.Rows.Count > 0)
        {
            DetailsView1.DataSource = dt;
            DetailsView1.DataBind();
        }
    }
}