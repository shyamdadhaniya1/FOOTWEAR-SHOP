﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;


public partial class maincart : System.Web.UI.Page
{
    String strcon = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\footwear.mdf;Integrated Security=True;User Instance=True";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        { 
            if(Session.Contents.Count>=0)
            {
                showcart();
            }
            
        }
    }
    protected void showcart()
    {
        SqlConnection con = new SqlConnection(strcon);
        con.Open();
        String qry = "select * from CART where UID='" + Session["uid"].ToString() + "'";
        SqlDataAdapter adpt = new SqlDataAdapter(qry,con);
        DataTable dt = new DataTable();
        adpt.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            Repeater1.DataSource = dt;
            Repeater1.DataBind();
        }

    }
    

    
    protected void btnCheck_Click(object sender, EventArgs e)
    {
        Response.Redirect("bill.aspx");
    }
    protected void btnShopping_Click(object sender, EventArgs e)
    {
        Response.Redirect("product.aspx");
    }
   
   
    protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName == "DELETE")
        {

            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            string qry = "DELETE FROM CART WHERE PID='" + e.CommandArgument + "'";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.ExecuteNonQuery();
            con.Close();
            Response.Redirect("maincart.aspx");
            Response.Write("<script>alert('DELETE Success')</script>");
        }
    }
}