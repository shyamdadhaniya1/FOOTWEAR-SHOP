﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Web.Configuration;


public partial class cart : System.Web.UI.Page
{
    String strcon = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\footwear.mdf;Integrated Security=True;User Instance=True";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            if (Session.Contents.Count == 0)
            {
                Session["cart"] = "cart.aspx?id=" + Request.QueryString["id"].ToString();
                Response.Redirect("login.aspx");
            }
            else
            {
                disp(Request.QueryString["id"].ToString());
            }
        }
    }
    protected void disp(string id)
    {
        SqlConnection con = new SqlConnection(strcon);

        SqlDataAdapter adpt = new SqlDataAdapter("select * From product where pid=" + id + "", con);
        DataTable dt = new DataTable();
        adpt.Fill(dt);

        if (dt.Rows.Count > 0)
        {
            //Session["price"]=dt.Rows[0]["p_price"].ToString();
            //Session["pname"] = dt.Rows[0]["p_name"].ToString();
            //Session["pimg"] = dt.Rows[0]["image"].ToString();

            Repeater1.DataSource = dt;
            Repeater1.DataBind();
        }
    }
    protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName == "CART")
        {

            Label nm = (Label)e.Item.FindControl("lblnm");
            Label price = (Label)e.Item.FindControl("lblprice");
            TextBox qty = (TextBox)e.Item.FindControl("txtqty");

            int total;
            int q = int.Parse(qty.Text);
            int p = int.Parse(price.Text);
            total = p * q;

            String tot = "(" + p.ToString() + "*" + q.ToString() + "=" + total.ToString() + ")";
            Image img = (Image)e.Item.FindControl("Image1");
            String pimg = img.ImageUrl.ToString();

            String pid = e.CommandArgument.ToString();

            SqlConnection con = new SqlConnection(strcon);
            con.Open();

            String qry = "insert into CART values('" + Session["uid"].ToString() + "','" + pid + "','" + nm.Text + "','" + pimg + "','" + tot + "')";

            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.ExecuteNonQuery();
            Response.Redirect("maincart.aspx");
        }
    }
}

 